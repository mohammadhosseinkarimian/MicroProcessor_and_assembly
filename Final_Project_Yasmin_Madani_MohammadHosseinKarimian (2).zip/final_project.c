/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 1/26/2022
Author  : 
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <stdio.h>
#include <mega32.h>
#include <delay.h>
// Alphanumeric LCD functions
#include <alcd.h>
#define ADC_VREF_TYPE ((1<<REFS1) | (1<<REFS0) | (0<<ADLAR))

void main(void)
{
unsigned int alph;
char arra[8];
int cond = 1;
DDRD = 0xFF;        
PORTD = 0;
DDRB = 0XF0;
ADMUX=ADC_VREF_TYPE;
ADCSRA= (0<<ADSC) | (1<<ADEN) | (0<<ADIE) | (0<<ADPS2) | (0<<ADATE) | (0<<ADIF) | (1<<ADPS1) | (1<<ADPS0);
SFIOR=(0<<ADTS2) | (0<<ADTS0) | (0<<ADTS1) ;
lcd_init(16);
delay_ms(1000);
lcd_gotoxy(3,0);
lcd_puts("SENSOR: LM35");
while (1)
      {   
        ADMUX=0 | ADC_VREF_TYPE;
        delay_us(10);
        ADCSRA|=(1<<ADSC);
        while ((ADCSRA & (1<<ADIF))==0);
        ADCSRA|=(1<<ADIF);
        alph = ADCW/4; 
        switch(cond){ 
            case 3: 
                if(alph > 30)
                    cond = 1;
                break;
            case 2:
                if(alph < 25)
                    cond = 1;
                break;
            case 1: 
                if(alph > 35)       
                    cond = 2;
                if(alph < 15)
                    cond = 3;
                break;    
        }  
        if(cond == 3)
            {
            PORTD = 0x90;
			delay_ms(100);
			PORTD = 0x80;
			delay_ms(100);
			PORTD = 0xC0;
			delay_ms(100);
			PORTD = 0x40;
			delay_ms(100);
			PORTD = 0x60;
			delay_ms(100);
			PORTD = 0x20;
			delay_ms(100);
			PORTD = 0x30;
			delay_ms(100);
			PORTD = 0x10;
			delay_ms(100);
			}
        if(cond == 2){     
            PORTD = 0x09;
            delay_ms(100);
            PORTD = 0x08;
            delay_ms(100);
            PORTD = 0x0C;
            delay_ms(100);
            PORTD = 0x04;
            delay_ms(100);
            PORTD = 0x06;
            delay_ms(100);
            PORTD = 0x02;
            delay_ms(100);
            PORTD = 0x03;
            delay_ms(100);
            PORTD = 0x01;
            delay_ms(100);
            }
        snprintf(arra, 8, "%d", alph);
        lcd_gotoxy(3,1);
        lcd_puts("TEMP : ");
        lcd_puts(arra);
        if(alph<100)
        {
        	lcd_puts(" ");
		}
        lcd_gotoxy(12,1);    
        lcd_putchar(0xDF);
        lcd_putchar('C');
      }
	while (1)
	{
	}
}