#include <stdio.h>
#include <dos.h>
#define GET_SYSTEM_DATE 0x2A

int main() {
    int day;
	int year;
	int month;    
    union REGS r_in, r_out;
    r_in.h.ah = GET_SYSTEM_DATE;
    int86(0x21, &r_in, &r_out);
    day = r_out.h.dl;
    month = r_out.h.dh;
    year = r_out.x.cx;
   if (month < 3 )
        year -= 622;
    else if (day < 21 && month == 3 )
        year -= 622;
    else
        year -= 621;     
    if (month == 10)
        if (day < 23)
            day += 8 ,month = 7;
        else
            day -= 22 ,month = 8;
       
	else if (month == 9 )
        if (day < 23)
            day += 9 ,month -= 3;
        else
            day -= 22 ,month -=2;

	else if (month == 8 )
        if (day < 23)
            day += 9 ,month -= 3;
        else
            day -= 22 ,month -=2;
	
	else if (month == 7 )
        if (day < 23)
            day += 9 ,month -= 3;
        else
            day -= 22 ,month -=2;     

	else if (month == 6)
        if (day < 22)
            month -= 3, day += 10;
        else
            month -= 2, day -= 21;

	else if (month == 5)
        if (day < 22)
            month -= 3, day += 10;
        else
            month -= 2, day -= 21;
    else if (month == 4)
        if (day < 21)
            month = 1, day += 11;
        else
            month = 2, day -= 20;

    else if (month == 3)
        if (day < 21)
            month = 12, day += 9;
        else
            month = 1, day -= 20;

    else if (month == 2)
        if (day < 20)
            month = 11, day += 11;
        else
            month = 12, day -= 19;  
    else if (month == 1)
        if (day < 21)
            month = 10, day += 10;
        else
            month = 11, day -= 20;
    else
        if (d < 22)
            month -= 3, day += 9;
        else
            month -= 2, day -= 21;
    printf("%d/%d/%d\n", year, month, day); 
    getch();
    return 0;
}
