/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 1/26/2022
Author  : 
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32.h>
#include <stdio.h>
#include <delay.h>
#include <alcd.h>

unsigned char dhttR(void)
{
    char CNTb=0 ;
    char dt=0;
    while(CNTb<8)
    {
        CNTb = CNTb + 1 ; 
        while(PIND.0==0);
        delay_us(30);
        if(PIND.0==1)
        {
            dt=(dt<<1)|(0x01);  
        }
        else
        {
            dt=dt<<1;
        }
        while(PIND.0==1);
    }
    return dt;
}
void main(void)
{
    char temperature=0 ;
    char humidity=0 ;
    char humiditym=0 ;
    char arraylcd[16] ;
    char sum=0; 
    char chsum=0 ;
    char temperaturem=0 ;
    DDRB.0=1;
    PORTB.0=0;
    lcd_init(16); 
    delay_ms(1000); 
    while (1)
    {   
        sum=0;
        DDRD.0=1;
        PORTD.0=0;
        delay_ms(20);
        PORTD.0=1; 
        DDRD.0=0;
        while(PIND.0==1);
        while(PIND.0==0);
        while(PIND.0==1);
        humidity=dhttR();  
        humiditym=dhttR();
        temperature=dhttR();
        temperaturem=dhttR();
        chsum=dhttR(); 
        sum= humidity+humiditym+temperature+temperaturem;
        if(sum!=chsum)continue;
        sprintf(arraylcd,"Humidity: %d %% ",humidity);
        lcd_gotoxy(0,0);
        lcd_puts(arraylcd);      
        if(humidity>60 || humidity<40)
            PORTB.0=1;
        else
            PORTB.0=0;
    }
}